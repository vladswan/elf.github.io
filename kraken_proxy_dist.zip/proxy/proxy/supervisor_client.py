from xmlrpc.client import ServerProxy


class ProcessStatus(object):
    RUNNING = 'RUNNING'
    STOPPED = 'STOPPED'
    FATAL = 'FATAL'
    RESTARTING = 'RESTARTING'
    SHUTDOWN = 'SHUTDOWN'


class SupervisorClient(object):
    """
    https://supervisor.readthedocs.io/en/latest/api.html

    уставновка
    https://serverfault.com/questions/96499/how-to-automatically-start-supervisord-on-linux-ubuntu

    https://gist.github.com/danmackinlay/176149
    https://github.com/illagrenan/ubuntu-supervisor-configuration

    Supervisor client to work with remote supervisor

    """

    def __init__(self, host='localhost', port=9001):
        self.server = ServerProxy('http://{}:{}/RPC2'.format(host, port))

    def _generate_correct_process_name(self, process):
        return "{}:1".format(process)

    def start(self, process):
        """ Start process
        :process: process name as String
        """
        return self.server.supervisor.startProcess(self._generate_correct_process_name(process))

    def stop(self, process):
        """ Stop process
        :process: process name as String
        """
        return self.server.supervisor.stopProcess(self._generate_correct_process_name(process))

    def status(self, process):
        """ Retrieve status process
        :process: process name as String
        """
        return self.server.supervisor.getProcessInfo(self._generate_correct_process_name(process))['statename']

if __name__ == '__main__':
    server = ServerProxy('http://localhost:9001/RPC2')
    print(server.supervisor.getState())