from settings.models import get_settings_by_name

def server(request):


    return {
        'servername': get_settings_by_name('server_name', 'Server Name'),
    }