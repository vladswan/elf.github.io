import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _7fafd98d = () => interopDefault(import('../pages/apn.vue' /* webpackChunkName: "pages/apn" */))
const _1f444250 = () => interopDefault(import('../pages/apn/index.vue' /* webpackChunkName: "pages/apn/index" */))
const _043a57c2 = () => interopDefault(import('../pages/apn/add.vue' /* webpackChunkName: "pages/apn/add" */))
const _c6c2ce90 = () => interopDefault(import('../pages/apn/_id.vue' /* webpackChunkName: "pages/apn/_id" */))
const _11f60cca = () => interopDefault(import('../pages/balance.vue' /* webpackChunkName: "pages/balance" */))
const _44975866 = () => interopDefault(import('../pages/balance/index.vue' /* webpackChunkName: "pages/balance/index" */))
const _6199be48 = () => interopDefault(import('../pages/balance/add.vue' /* webpackChunkName: "pages/balance/add" */))
const _2b81400c = () => interopDefault(import('../pages/balance/history/_id.vue' /* webpackChunkName: "pages/balance/history/_id" */))
const _6deee575 = () => interopDefault(import('../pages/balance/_id.vue' /* webpackChunkName: "pages/balance/_id" */))
const _19bed661 = () => interopDefault(import('../pages/home.vue' /* webpackChunkName: "pages/home" */))
const _2728291a = () => interopDefault(import('../pages/ips.vue' /* webpackChunkName: "pages/ips" */))
const _7bd3f41d = () => interopDefault(import('../pages/ips/index.vue' /* webpackChunkName: "pages/ips/index" */))
const _eb42d5a8 = () => interopDefault(import('../pages/ips/add.vue' /* webpackChunkName: "pages/ips/add" */))
const _291a59c5 = () => interopDefault(import('../pages/ips/_id.vue' /* webpackChunkName: "pages/ips/_id" */))
const _47c64fac = () => interopDefault(import('../pages/logins.vue' /* webpackChunkName: "pages/logins" */))
const _f3e935a2 = () => interopDefault(import('../pages/logins/index.vue' /* webpackChunkName: "pages/logins/index" */))
const _4b8322be = () => interopDefault(import('../pages/logins/add.vue' /* webpackChunkName: "pages/logins/add" */))
const _2b823152 = () => interopDefault(import('../pages/logins/_id.vue' /* webpackChunkName: "pages/logins/_id" */))
const _a068819e = () => interopDefault(import('../pages/logs.vue' /* webpackChunkName: "pages/logs" */))
const _2f1e748b = () => interopDefault(import('../pages/modems.vue' /* webpackChunkName: "pages/modems" */))
const _004626ce = () => interopDefault(import('../pages/modems/index.vue' /* webpackChunkName: "pages/modems/index" */))
const _63207fc6 = () => interopDefault(import('../pages/modems/add.vue' /* webpackChunkName: "pages/modems/add" */))
const _63b32ce6 = () => interopDefault(import('../pages/modems/group/add.vue' /* webpackChunkName: "pages/modems/group/add" */))
const _0483b7e9 = () => interopDefault(import('../pages/modems/group/link/_id.vue' /* webpackChunkName: "pages/modems/group/link/_id" */))
const _f5ceeedc = () => interopDefault(import('../pages/modems/group/mode/_id.vue' /* webpackChunkName: "pages/modems/group/mode/_id" */))
const _6ce22e26 = () => interopDefault(import('../pages/modems/group/_id.vue' /* webpackChunkName: "pages/modems/group/_id" */))
const _ff4c094e = () => interopDefault(import('../pages/modems/link/_id.vue' /* webpackChunkName: "pages/modems/link/_id" */))
const _00eecc02 = () => interopDefault(import('../pages/modems/mode/_id.vue' /* webpackChunkName: "pages/modems/mode/_id" */))
const _f4002a24 = () => interopDefault(import('../pages/modems/pof/_id.vue' /* webpackChunkName: "pages/modems/pof/_id" */))
const _6d2b84b6 = () => interopDefault(import('../pages/modems/_id.vue' /* webpackChunkName: "pages/modems/_id" */))
const _736d4ab4 = () => interopDefault(import('../pages/operator.vue' /* webpackChunkName: "pages/operator" */))
const _7d74cca9 = () => interopDefault(import('../pages/operator/index.vue' /* webpackChunkName: "pages/operator/index" */))
const _6b3420b8 = () => interopDefault(import('../pages/operator/add.vue' /* webpackChunkName: "pages/operator/add" */))
const _09efe551 = () => interopDefault(import('../pages/operator/_id.vue' /* webpackChunkName: "pages/operator/_id" */))
const _f3c8a648 = () => interopDefault(import('../pages/proxy.vue' /* webpackChunkName: "pages/proxy" */))
const _7f521e5f = () => interopDefault(import('../pages/proxy/index.vue' /* webpackChunkName: "pages/proxy/index" */))
const _788667ee = () => interopDefault(import('../pages/proxy/add.vue' /* webpackChunkName: "pages/proxy/add" */))
const _4d814ef7 = () => interopDefault(import('../pages/proxy/export.vue' /* webpackChunkName: "pages/proxy/export" */))
const _6a3ced10 = () => interopDefault(import('../pages/proxy/generate.vue' /* webpackChunkName: "pages/proxy/generate" */))
const _17422c87 = () => interopDefault(import('../pages/proxy/_id.vue' /* webpackChunkName: "pages/proxy/_id" */))
const _42104c45 = () => interopDefault(import('../pages/server.vue' /* webpackChunkName: "pages/server" */))
const _2581cb08 = () => interopDefault(import('../pages/server/index.vue' /* webpackChunkName: "pages/server/index" */))
const _e8d5e6b6 = () => interopDefault(import('../pages/server/log/_id.vue' /* webpackChunkName: "pages/server/log/_id" */))
const _0686cb62 = () => interopDefault(import('../pages/server/proxy/_id.vue' /* webpackChunkName: "pages/server/proxy/_id" */))
const _27c3d2b6 = () => interopDefault(import('../pages/settings.vue' /* webpackChunkName: "pages/settings" */))
const _26d7774d = () => interopDefault(import('../pages/user.vue' /* webpackChunkName: "pages/user" */))
const _6c2e9010 = () => interopDefault(import('../pages/user/index.vue' /* webpackChunkName: "pages/user/index" */))
const _688591df = () => interopDefault(import('../pages/user/add.vue' /* webpackChunkName: "pages/user/add" */))
const _07415678 = () => interopDefault(import('../pages/user/_id.vue' /* webpackChunkName: "pages/user/_id" */))
const _72593940 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _1c25cfc3 = () => interopDefault(import('../pages/index/index.vue' /* webpackChunkName: "pages/index/index" */))
const _b59f608c = () => interopDefault(import('../pages/index/password.vue' /* webpackChunkName: "pages/index/password" */))
const _0a73f098 = () => interopDefault(import('../pages/index/recovery.vue' /* webpackChunkName: "pages/index/recovery" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/apn",
    component: _7fafd98d,
    children: [{
      path: "",
      component: _1f444250,
      name: "apn"
    }, {
      path: "add",
      component: _043a57c2,
      name: "apn-add"
    }, {
      path: ":id",
      component: _c6c2ce90,
      name: "apn-id"
    }]
  }, {
    path: "/balance",
    component: _11f60cca,
    children: [{
      path: "",
      component: _44975866,
      name: "balance"
    }, {
      path: "add",
      component: _6199be48,
      name: "balance-add"
    }, {
      path: "history/:id?",
      component: _2b81400c,
      name: "balance-history-id"
    }, {
      path: ":id",
      component: _6deee575,
      name: "balance-id"
    }]
  }, {
    path: "/home",
    component: _19bed661,
    name: "home"
  }, {
    path: "/ips",
    component: _2728291a,
    children: [{
      path: "",
      component: _7bd3f41d,
      name: "ips"
    }, {
      path: "add",
      component: _eb42d5a8,
      name: "ips-add"
    }, {
      path: ":id",
      component: _291a59c5,
      name: "ips-id"
    }]
  }, {
    path: "/logins",
    component: _47c64fac,
    children: [{
      path: "",
      component: _f3e935a2,
      name: "logins"
    }, {
      path: "add",
      component: _4b8322be,
      name: "logins-add"
    }, {
      path: ":id",
      component: _2b823152,
      name: "logins-id"
    }]
  }, {
    path: "/logs",
    component: _a068819e,
    name: "logs"
  }, {
    path: "/modems",
    component: _2f1e748b,
    children: [{
      path: "",
      component: _004626ce,
      name: "modems"
    }, {
      path: "add",
      component: _63207fc6,
      name: "modems-add"
    }, {
      path: "group/add",
      component: _63b32ce6,
      name: "modems-group-add"
    }, {
      path: "group/link/:id?",
      component: _0483b7e9,
      name: "modems-group-link-id"
    }, {
      path: "group/mode/:id?",
      component: _f5ceeedc,
      name: "modems-group-mode-id"
    }, {
      path: "group/:id?",
      component: _6ce22e26,
      name: "modems-group-id"
    }, {
      path: "link/:id?",
      component: _ff4c094e,
      name: "modems-link-id"
    }, {
      path: "mode/:id?",
      component: _00eecc02,
      name: "modems-mode-id"
    }, {
      path: "pof/:id?",
      component: _f4002a24,
      name: "modems-pof-id"
    }, {
      path: ":id",
      component: _6d2b84b6,
      name: "modems-id"
    }]
  }, {
    path: "/operator",
    component: _736d4ab4,
    children: [{
      path: "",
      component: _7d74cca9,
      name: "operator"
    }, {
      path: "add",
      component: _6b3420b8,
      name: "operator-add"
    }, {
      path: ":id",
      component: _09efe551,
      name: "operator-id"
    }]
  }, {
    path: "/proxy",
    component: _f3c8a648,
    children: [{
      path: "",
      component: _7f521e5f,
      name: "proxy"
    }, {
      path: "add",
      component: _788667ee,
      name: "proxy-add"
    }, {
      path: "export",
      component: _4d814ef7,
      name: "proxy-export"
    }, {
      path: "generate",
      component: _6a3ced10,
      name: "proxy-generate"
    }, {
      path: ":id",
      component: _17422c87,
      name: "proxy-id"
    }]
  }, {
    path: "/server",
    component: _42104c45,
    children: [{
      path: "",
      component: _2581cb08,
      name: "server"
    }, {
      path: "log/:id?",
      component: _e8d5e6b6,
      name: "server-log-id"
    }, {
      path: "proxy/:id?",
      component: _0686cb62,
      name: "server-proxy-id"
    }]
  }, {
    path: "/settings",
    component: _27c3d2b6,
    name: "settings"
  }, {
    path: "/user",
    component: _26d7774d,
    children: [{
      path: "",
      component: _6c2e9010,
      name: "user"
    }, {
      path: "add",
      component: _688591df,
      name: "user-add"
    }, {
      path: ":id",
      component: _07415678,
      name: "user-id"
    }]
  }, {
    path: "/",
    component: _72593940,
    children: [{
      path: "",
      component: _1c25cfc3,
      name: "index"
    }, {
      path: "password",
      component: _b59f608c,
      name: "index-password"
    }, {
      path: "recovery",
      component: _0a73f098,
      name: "index-recovery"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
