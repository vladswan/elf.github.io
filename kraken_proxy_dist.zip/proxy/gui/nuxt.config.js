import colors from 'vuetify/es5/util/colors'

export default {
  telemetry: false,
  head: {
    titleTemplate: '%s ',
    title: 'Kraken Proxy',
    meta: [
      {charset: 'utf-8'},
      {name: 'viewport', content: 'width=device-width, initial-scale=1'},
      {hid: 'description', name: 'description', content: ''}
    ],
    link: [
      {rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg'}
    ]
  },
  // Global CSS (https://go.nuxtjs.dev/config-css)
  css: [],
  loading: {color: '#4ba00e'},

  // Plugins to run before rendering page (https://go.nuxtjs.dev/config-plugins)
  plugins: [
    {src: "~/plugins/axios"},
    {src: "~/plugins/api"},
    {src: '~/plugins/vee-validate'},
    {src: '~/plugins/v-mask'},
    {src: '~/plugins/echarts', ssr: false},
  ],

  axios: {
    credentials: true,
    debug: false,
    proxy: true,
  },
  proxy: {
    '/api': {
      target: process.env.API_URL,
      changeOrigin: true
    },
    '/ws': {
      target: process.env.WS_URL,
      changeOrigin: true,
      ws:true
    }
  },

  publicRuntimeConfig: {
    ws: 'ws://'
  },

  privateRuntimeConfig: {},


  // Auto import components (https://go.nuxtjs.dev/config-components)
  components: true,

  // Modules for dev and build (recommended) (https://go.nuxtjs.dev/config-modules)
  buildModules: [
    // https://go.nuxtjs.dev/vuetify
    '@nuxtjs/vuetify',
  ],

  // Modules (https://go.nuxtjs.dev/config-modules)
  modules: [
    '@nuxtjs/axios',
    '@nuxtjs/proxy',
    'cookie-universal-nuxt',
    '@nuxtjs/device',
  ],

  // Vuetify module configuration (https://go.nuxtjs.dev/config-vuetify)
  vuetify: {
    customVariables: ['~/assets/variables.scss'],
  },

  // Build Configuration (https://go.nuxtjs.dev/config-build)
  build: {}
}
