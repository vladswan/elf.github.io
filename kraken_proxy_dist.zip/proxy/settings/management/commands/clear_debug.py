from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from devices.models import Modem, Operators, NetworkType, ModemTraffic, ModemIP, OperatorIP
from info.models import MessagesText, LogsMessages
from server.api import save_config
from devices.api import NMConnections
import os
from devices.ModemManager import ModemManager
from django_celery_beat.models import PeriodicTask, IntervalSchedule, CrontabSchedule
from proxy.celery import app
from django.core import exceptions

class Command(BaseCommand):
    help = ''

    def handle(self, *args, **kwargs):

        for file_name in os.listdir('/var/log/3proxy/'):
            os.remove(os.path.join('/var/log/3proxy/', file_name))

        for file_name in os.listdir('/home/proxy/log/'):
            os.remove(os.path.join('/home/proxy/log/', file_name))

        MessagesText.objects.all().delete()
        ModemTraffic.objects.all().delete()
        ModemIP.objects.all().delete()
        LogsMessages.objects.all().delete()
        OperatorIP.objects.all().delete()
