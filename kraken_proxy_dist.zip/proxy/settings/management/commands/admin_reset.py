from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from devices.models import Modem, Operators, NetworkType
from server.models import Proxy, ProxyAuthLogin, ProxyAuthIP, ProxyAllow
from info.models import MessagesText
from server.api import save_config
from devices.api import NMConnections
import os
from devices.ModemManager import ModemManager
from django_celery_beat.models import PeriodicTask, IntervalSchedule, CrontabSchedule
from proxy.celery import app
from django.core import exceptions

class Command(BaseCommand):
    help = ''

    def handle(self, *args, **kwargs):

        User.objects.filter(is_superuser=True).all().delete()
