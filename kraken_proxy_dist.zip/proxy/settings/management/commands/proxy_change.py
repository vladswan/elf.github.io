from django.core.management.base import BaseCommand, CommandError
from django.core import exceptions
from django.conf import settings
from django.contrib.sites.models import Site
import requests
import os
import json
from devices.models import Modem
import arrow
class Command(BaseCommand):
    help = 'Обновление прокси'

    def handle(self, *args, **kwargs):
        for item in Modem.objects.all():
            proxy = item.proxy_set.last()
            if proxy:
                proxy.date_update = arrow.now().datetime
                proxy.save()
