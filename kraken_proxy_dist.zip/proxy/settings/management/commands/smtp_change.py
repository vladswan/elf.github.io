from django.core.management.base import BaseCommand, CommandError
from django.core import exceptions
from django.conf import settings
import os
import json

class Command(BaseCommand):
    help = 'Настройка почтового сервера'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def add_arguments(self, parser):

        parser.add_argument('-e', '--email', type=str, help='E-mail - адрес ящика для отправки')
        parser.add_argument('-s', '--smtp', type=str, help='Адрес smtp сервера')
        parser.add_argument('-p', '--port', type=int, help='smtp порт сервера')
        parser.add_argument('-u', '--user', type=str, help='Логин (адрес почты)')
        parser.add_argument('-w', '--password', type=str, help='Пароль от ящика')
        parser.add_argument('-l', '--ssl', type=str, help='Использовать SSL (Y/N)')


    def handle(self, *args, **kwargs):
        email = kwargs['email']
        smtp = kwargs['smtp']
        port = kwargs['port']
        user = kwargs['user']
        password = kwargs['password']
        ssl = kwargs['ssl']

        if not email:
            email = self.get_input_data('E-mail - адрес ящика для отравки: ')
            if not email:
                raise CommandError('E-mail - адрес ящика для отравки обязателен')

        if not smtp:
            smtp = self.get_input_data('Адрес smtp сервера: ')
            if not smtp:
                raise CommandError('Адрес smtp сервера обязателен')

        if not port:
            port = self.get_input_data('smtp порт сервера: ')
            if not port:
                raise CommandError('smtp порт сервера обязателен')

        if not user:
            user = self.get_input_data('Логин (адрес почты): ')
            if not user:
                raise CommandError('Логин (адрес почты) обязателен')

        if not password:
            password = self.get_input_data('Пароль от ящика: ')
            if not password:
                raise CommandError('Пароль от ящика обязателен')

        if not ssl:
            ssl = self.get_input_data('Использовать SSL (Y/N): ')

        if not ssl or not ssl in ('Y', 'N'):
            ssl = False
        else:
            ssl = True if ssl == 'Y' else False

        path_settings = os.path.join(settings.BASE_DIR, 'settings.json')

        data = {}
        if os.path.isfile(path_settings):
            with open(path_settings, "r") as read_file:
                data = json.load(read_file)

        data = {
            "DEFAULT_FROM_EMAIL":email,
            "EMAIL_HOST":smtp,
            "EMAIL_PORT":port,
            "EMAIL_HOST_USER":user,
            "EMAIL_HOST_PASSWORD":password,
            "EMAIL_USE_SSL":ssl
        }

        with open(path_settings, "w") as write_file:
            json.dump(data, write_file)

        self.stdout.write(self.style.SUCCESS(u'Настройки для отправки почты успешно сохранены'))

    def get_input_data(self,  message, default=None):

        raw_value = input(message)
        if default and raw_value == '':
            raw_value = default
        try:
            val = raw_value
        except exceptions.ValidationError as e:
            self.stderr.write("Error: %s" % '; '.join(e.messages))
            val = None

        return val