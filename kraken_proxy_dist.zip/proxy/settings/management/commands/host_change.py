from django.core.management.base import BaseCommand, CommandError
from django.core import exceptions
from django.conf import settings
from django.contrib.sites.models import Site
import requests
import os
import json
from devices.api import NMDevices

class Command(BaseCommand):
    help = 'Настройка веб-сервера'

    def add_arguments(self, parser):

        parser.add_argument('-i', '--ip', type=str, help='Внешний IP адрес')


    def handle(self, *args, **kwargs):
        ip = kwargs['ip']

        if not ip:
            try:
                response = requests.get('http://ip-api.com/json/?lang=ru', timeout=4)
                if response.status_code == 200:
                    result = response.json()
                    if result.get('query'):
                        ip = result.get('query')
            except:
                pass

        if ip:
            inst = Site.objects.get(pk=settings.SITE_ID)

            inst.domain = '{0}:8080'.format(ip)
            inst.name = 'kraken-proxy'
            inst.save()
