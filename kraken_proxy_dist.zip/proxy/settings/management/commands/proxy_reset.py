from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from devices.models import Modem, Operators, NetworkType
from server.models import Proxy, ProxyAuthLogin, ProxyAuthIP, ProxyAllow
from info.models import MessagesText
from server.api import save_config
from devices.api import NMConnections
import os
from devices.ModemManager import ModemManager
from django_celery_beat.models import PeriodicTask, IntervalSchedule, CrontabSchedule
from proxy.celery import app
from django.core import exceptions

class Command(BaseCommand):
    help = ''

    def handle(self, *args, **kwargs):

    
        Proxy.objects.all().delete()
        for file_name in os.listdir('/etc/3proxy/'):
            os.remove(os.path.join('/etc/3proxy/', file_name))


        for modem in Modem.objects.all():
            modem_type = modem.type.interface

            for item in NMConnections().filter(id='modem-id-{0}'.format(modem.id)).all():
                item.remove()

            if modem_type == 'eth':

                for item in NMConnections().filter(ifname=modem.ifname).all():
                    item.remove()

            elif modem_type == 'gsm':
                try:
                    modem_mr = ModemManager().filter(equipment_id=modem.ifname).get()
                    for item in NMConnections().filter(ifname=modem_mr.port).all():
                        item.remove()
                except:
                    pass

            if modem.monitoring_task:
                app.control.revoke(modem.monitoring_task.id, terminate=True)
                PeriodicTask.objects.get(pk=modem.monitoring_task.id).delete()
            if modem.reconnect_task:
                app.control.revoke(modem.reconnect_task.id, terminate=True)
                PeriodicTask.objects.get(pk=modem.reconnect_task.id).delete()

            modem.delete()

        PeriodicTask.objects.all().delete()
        IntervalSchedule.objects.all().delete()
        Operators.objects.all().delete()
        NetworkType.objects.all().delete()
        ProxyAuthLogin.objects.all().delete()
        ProxyAuthIP.objects.all().delete()
        ProxyAllow.objects.all().delete()
        MessagesText.objects.all().delete()
        Token.objects.all().delete()
        User.objects.all().delete()

    def get_input_data(self,  message, default=None):

        raw_value = input(message)
        if default and raw_value == '':
            raw_value = default
        try:
            val = raw_value
        except exceptions.ValidationError as e:
            self.stderr.write("Error: %s" % '; '.join(e.messages))
            val = None

        return val