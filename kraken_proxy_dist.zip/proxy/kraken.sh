#!/bin/bash

function SetLogFile {
    export LOG_FILE="/tmp/install_kraken.debug"

    if [ -f "$LOG_FILE" ]; then
        rm "$LOG_FILE"
    fi

    exec 3>&1
    exec &> $LOG_FILE
}
function CheckIsUserRoot () {

  if [ `id -u` -eq 0 ]; then
      Debug "User run is root"
  else
      Error 'The script must be run as the root user.'
  fi

}
function CheckArch {
    if [ `arch` = "x86_64" ]; then
        Debug "Architecture x86_64."
    else
        Error 'Kraken Proxy supports only x86_64 Architecture.'
    fi
}
function InstallationFailed {
    if [ ! -z "$1" ]; then
        Debug "$1"
    fi
    printf "\033[1;31m[Failed]\033[0m\n" >&3
    printf "\033[1;31m\nOops! I've failed to install control panel... Please look for the reason in \"${LOG_FILE}\" log file.'\nsend the file to my creators by email info@kraken-proxy.ru\033[0m\n" >&3
    exit 1
}
function Error {
    printf "\033[1;31m$@\033[0m\n" >&3
    exit 1
}
function Message {
    printf "\033[1;36m$@\033[0m" >&3
    Debug "$@\n"
}
function Warning {
    printf "\033[1;35m$@\033[0m" >&3
    Debug "$@\n"
}
function Info {
    printf "\033[00;32m$@\033[0m" >&3
    Debug "$@\n"
}
function Debug {
    printf "$@\n"
}
function Success {
    printf "\033[00;32m[Success]\n\033[0m" >&3
}
function Danger {
    printf "\033[1;31m$@\033[0m\n" >&3
    Debug "$@\n"
}
function ShowLogo {
cat << "EOF" >&3
      _  __          _                _____
     | |/ /         | |              |  __ \
     | ' / _ __ __ _| | _____ _ __   | |__) | __ _____  ___   _
     |  < | '__/ _` | |/ / _ \ '_ \  |  ___/ '__/ _ \ \/ / | | |
     | . \| | | (_| |   <  __/ | | | | |   | | | (_) >  <| |_| |
     |_|\_\_|  \__,_|_|\_\___|_| |_| |_|   |_|  \___/_/\_\\__, |
                                                           __/ |
                                                          |___/
EOF
}
function CheckVersionOS {

    source /etc/os-release
    case ${ID} in
        ubuntu )
          export FAMILY='ubuntu'
            case ${VERSION_ID} in
                18.04 )
                  export OS='bionic'
                    ;;
                * )
                  Error 'Unsupported Ubuntu version.'
                    ;;
            esac
            ;;
        * )
          Error 'Unsupported OS version.'
          ;;
    esac
}
function ParseParameters {

    export DOMAINS="eu.kraken-proxy.ru api.kraken-proxy.ru"

    while [ "$1" != "" ]; do
        case $1 in
            --ver )
              shift
              export ver=$1
              ;;
            --restart )
              export restart=1
              ;;
            -f | --force )
              export force=1
              ;;
            -a | --radmin )
              export radmin=1
              ;;
            -c | --clear )
              export clear=1
              ;;
            -v | --version )
              export version=1
              ;;
            -r | --reset )
              export reset=1
              ;;
            -m | --smtp )
              export smtp=1
              ;;
            -u | --update )
              export update=1
              ;;
            -h | --help )
              Usage
              exit
              ;;
            * )
              Usage
              Error "Unknown option: \"$1\"."
        esac
        shift
    done
}
function Usage {
    cat << EOU >&3

Usage:  $0 [-h|--help]

Options:
    -h, --help            Print this help
    -f, --force           Skip check installed software
    -u, --update          Update Kraken Proxy software to latest version
    -m, --smtp            Set smtp server
    -v, --version         Get version kraken proxy
    -r, --reset           Reset all data (users, ports, proxies) create a new admin
    -a, --radmin          Reset admin
    -c, --clear           Clear logs and statistics
    --restart             Full restart (kraken proxy, service)
    --ver                 Specify the version of the software to download and install, the minimum version is 1.12.1
EOU
}
function UpdateSoftwareList {
    Message "Update linux\n"
    apt-get update -qq || InstallationFailed "Please check apt"
}
function InstallPanelRepository {

    case `grep -E "universe"  /etc/apt/sources.list -c` in
            0 )     Debug "add  repository universe"
                    add-apt-repository universe
                    ;;
            * )     Debug "is repository universe"
                    ;;
    esac

    if ! [ -f /home/kraken_proxy_dist.zip ];  then

      local error_text=""

      for domain in ${DOMAINS}; do

          if [ -n "${ver}" ]; then

            if ! wget --quiet -O /home/kraken_proxy_dist.zip "https://${domain}/api/license/dist/source?version=${ver}"; then
                rm /home/kraken_proxy_dist.zip
                error_text="not wget download https://${domain}/api/license/dist/source?version=${ver} version ${ver} dist kraken proxy, add your ip in your account"
            else
              error_text=""
              break
            fi

          else
            if ! wget --quiet -O /home/kraken_proxy_dist.zip "https://${domain}/api/license/dist/source"; then
              rm /home/kraken_proxy_dist.zip
              error_text="not wget download https://${domain}/api/license/dist/source dist kraken proxy, add your ip in your account"
            else
              error_text=""
              break
            fi
          fi
      done

      if [ -n "${error_text}" ]; then
        Error "${error_text}"
      fi


      Message "Download dist kraken proxy\n"
    fi
}
function CheckNetworkManagerPackage {
    case `dpkg --get-selections |grep -E "network-manager?\s+install" -c` in
            0 )     Debug "Package 'network-manager' not installed."
                    apt-get install -y network-manager
                    systemctl start NetworkManager
                    systemctl start ModemManager
                    Message "The package 'network-manager' is installed\n"
                    ;;
            * )     Debug "The package 'network-manager' is installed"
                    ;;
    esac
}
function CheckRabbitmqServerPackage {
    case `dpkg --get-selections |grep -E "rabbitmq-server?\s+install" -c` in
            0 )     Debug "Package 'rabbitmq-server' not installed."
                    apt-get install -y rabbitmq-server
                    systemctl enable rabbitmq-server
                    systemctl start rabbitmq-server
                    Message "The package 'rabbitmq-server' is installed\n"
                    ;;
            * )     Debug "The package 'rabbitmq-server' is installed"
                    ;;
    esac
}
function CheckRedisServerPackage {
    case `dpkg --get-selections |grep -E "redis-server?\s+install" -c` in
            0 )     Debug "Package 'redis-server' not installed."
                    apt-get install -y redis-server
                    systemctl enable redis-server
                    systemctl start redis-server
                    Message "The package 'redis-server' is installed\n"
                    ;;
            * )     Debug "The package 'redis-server' is installed"
                    ;;
    esac
}
function CheckPostgresqlServerPackage {
    case `dpkg --get-selections |grep -E "postgresql?\s+install" -c` in
            0 )     Debug "Package 'postgresql' not installed."
                    apt-get -y install postgresql postgresql-contrib
                    systemctl enable postgresql
                    systemctl start postgresql
                     Message "The package 'postgresql' is installed\n"
                    ;;
            * )     Debug "The package 'postgresql' is installed"
                    ;;
    esac
}
function CheckNginxServerPackage {
    case `dpkg --get-selections |grep -E "nginx?\s+install" -c` in
            0 )     Debug "Package 'nginx' not installed."
                    apt-get -y install nginx
                    systemctl enable nginx
                    systemctl start nginx
                    Message "The package 'nginx' is installed\n"
                    ;;
            * )     Debug "The package 'postgresql' is installed"
                    ;;
    esac
}
function CheckUnzipPackage {
    case `dpkg --get-selections | grep -E "unzip?\s+install" -c` in
            0 )
              Debug "Package 'unzip' not installed."
              apt-get -y install unzip
              Message "The package 'unzip' is installed\n"
              ;;
            * )
              Debug "The package 'unzip' is installed"
            ;;
      esac
}
function CheckPythonNfqueueServerPackage {
    case `dpkg --get-selections | grep -E "python-nfqueue?\s+install" -c` in
            0 )
                    Debug "The package 'python-nfqueue' is installed"
                    ;;
            * )     Debug "Package 'python-nfqueue' not installed."
                    wget --quiet http://mirrors.kernel.org/ubuntu/pool/universe/n/nfqueue-bindings/python-nfqueue_0.5-1build2_amd64.deb || InstallationFailed "not wget python-nfqueue"
                    dpkg -i python-nfqueue_0.5-1build2_amd64.deb
                    apt-mark hold python-nfqueue
                    Message "The package 'nfqueue' is installed\n"
                    ;;
    esac
}
function CheckLibPackage {


  local PACKAGES="python3-dev libpq-dev libdbus-glib-1-dev build-essential software-properties-common python-pip libnetfilter-queue1 supervisor ntp"
  for package in ${PACKAGES}; do

      case `dpkg --get-selections | grep -E "${package}\s+install" -c` in
          0 )
            Debug "Package '${package}' not installed."
            apt-get -y install ${package}
            Message "The package '${package}' is installed\n"
            ;;
          * )
            Debug "The package '${package}' is installed"
            ;;
      esac
  done
}
function CheckOSFPLibPackage {

  local PACKAGES1="scapy dpkt netaddr "

  for package in ${PACKAGES1}; do

      case `pip2 list | grep -E "${package}" -c` in
          0 )
            Debug "Package PIP2 '${package}' not installed."
            pip2 install ${package}
            ;;
          * )
            Debug "The package PIP2 '${package}' is installed"
            ;;
      esac
  done
}
function Check3PoxyPackage {

  case `dpkg --get-selections |grep -E "3proxy?\s+install" -c` in
            0 )     Debug "Package '3proxy' not installed."
                    ;;
            * )     Debug "The package '3proxy' is installed"
                    service 3proxy stop
                    systemctl disable 3proxy
                    if [ -d /etc/init.d/3proxy ]; then
                      rm -r /etc/init.d/3proxy
                    fi
                    ;;
  esac

  if [ -f /usr/bin/3proxy ]; then
    Debug "The bin '3proxy' is installed"
  else
    wget --quiet https://github.com/z3APA3A/3proxy/archive/0.8.13.tar.gz || InstallationFailed "not wget 3proxy"
    tar xzf 0.8.13.tar.gz
    cd 3proxy-*
    make -f Makefile.Linux
    adduser --system --quiet --disabled-login --no-create-home --group proxy3

    if ! [ -d /var/log/3proxy ]; then
      mkdir -p /var/log/3proxy
    fi

    if ! [ -d /etc/3proxy ]; then
      mkdir /etc/3proxy
    fi

    cp -f src/3proxy /usr/bin/

    chown proxy3:proxy3 -R /etc/3proxy
    chown proxy3:proxy3 /usr/bin/3proxy
    chown proxy3:proxy3 /var/log/3proxy
    cd ../
    rm xzf 0.8.13.tar.gz
    rm -r 3proxy-*

    Message "The package '3proxy' is installed\n"

  fi

}
function CheckPyVirtualenvPackage {

  case `dpkg --get-selections |grep -E "python3-pip?\s+install" -c` in
            0 )     Debug "Package 'python3-pip' not installed."
#                    wget --quiet https://bootstrap.pypa.io/get-pip.py || InstallationFailed "not wget tps://bootstrap.pypa.io/get-pip.py"
#                    python3 get-pip.py
                     apt-get -y  install python3-pip
                    ;;
            * )     Debug "The package 'python3-pip' is installed"
                    ;;
  esac

  case `pip3 list | grep -E "virtualenv" -c` in
          0 )
            Debug "Package PIP3 'virtualenv' not installed."
            pip3 install virtualenv
            ;;
          * )
            Debug "The package PIP3 'virtualenv' is installed"
            ;;
  esac

  if [ -d /home/proxy/venv ]; then
    Debug "The virtualenv 'kraken' is installed"
  else
    Debug "The virtualenv create /home/proxy/venv"
    virtualenv -p python3  /home/proxy/venv
  fi

}
function CheckNodeJsPackage {

  if [ `dpkg --get-selections | grep -E "nodejs?\s+install" -c`= 0 ] || [ `nodejs -v | grep -E "v15.*" -c` = 0  ]; then
    Debug "Package 'nodejs' not installed."
    curl -sL https://deb.nodesource.com/setup_15.x | sudo bash -
    sudo apt-get install -y nodejs
  else
    Debug "The package 'nodejs' is installed"
  fi

}
function ActiveVenv {
  cd /home/proxy/
  source venv/bin/activate
}
function CreateUser {
  ActiveVenv

  if [ `sudo -u postgres psql -d proxy -c "SELECT is_superuser FROM auth_user WHERE is_superuser=true;" | grep -E "t" -c` = 0 ]; then
    python manage.py createsuperuser  >&3
    python manage.py create_token_superuser
  fi

}
function SmtpSettings {
  ActiveVenv
  python manage.py smtp_change  >&3
}
function SetHost {
  ActiveVenv
  python manage.py host_change
}
function InstallLibKraken {
  ActiveVenv
  pip install -r req.txt
  pip install uwsgi
}
function MigrateDataBase {
  ActiveVenv
  python manage.py makemigrations
  python manage.py migrate
  python manage.py loaddata /home/proxy/devices/fixtures/initial_data.json
  python manage.py loaddata /home/proxy/settings/fixtures/initial_data.json
}
function ConfigRabbitmq {
  case `rabbitmqctl list_users | grep -E "krakenproxy" -c` in
            0 )     Debug "rabbitmq 'krakenproxy' not user create."
                    sudo rabbitmqctl add_user krakenproxy kraken123proxy
                    sudo rabbitmqctl add_vhost /
                    sudo rabbitmqctl set_user_tags krakenproxy administrator
                    sudo rabbitmqctl set_permissions -p / krakenproxy ".*" ".*" ".*"
                    ;;
            * )     Debug "rabbitmq 'krakenproxy' is user create."
                    ;;
  esac
}
function ConfigPostgresql {
  case `sudo -u postgres psql -l | grep -E "proxy" -c` in
            0 )     Debug "Postgresql 'krakenproxy' not database."
                    sudo -u postgres createdb proxy
                    sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'proxy';"
                    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE proxy TO postgres;"
                    ;;
            * )     Debug "Postgresql 'krakenproxy' is create database."
                    ;;
  esac
}
function InstallUiKrakenProxy {
    CheckNodeJsPackage
    if [ -d /home/proxy/gui ]; then
      cd /home/proxy/gui
      npm install --save nuxt
      npm i

    fi

    if ! [ -f /home/proxy/gui/.env ]; then
    cat > /home/proxy/gui/.env <<EOF
API_URL=http://localhost:8000/
WS_URL=ws://localhost:8000
EOF
    fi
}
function IsKrakenPackage {
  [ -f /home/proxy/manage.py ] && [ `sudo -u postgres psql -l | grep -E "proxy" -c` ]
}
function CheckKrakenPackage {
  if [ -f /home/proxy/manage.py ]; then
    Debug "The package 'kraken' is installed"
  else
    Debug "Unzip package kraken_proxy_dist.zip"
    unzip /home/kraken_proxy_dist.zip -d /home
  fi

  CheckPyVirtualenvPackage
  InstallLibKraken
  MigrateDataBase
  CreateUser
  SmtpSettings
  SetHost
  Message "Start UI 'Kraken' installed\n"
  InstallUiKrakenProxy
  Message "The package 'Kraken' is installed\n"

  if [ -d /home/proxy/log ]; then
    mkdir /home/proxy/log
  fi

  if [ -f /home/kraken_proxy_dist.zip ]; then
    rm /home/kraken_proxy_dist.zip
  fi
}
function ConfigNginx {
  if ! [ -f /etc/nginx/sites-enabled/api.local.conf  ]; then
    cat > /etc/nginx/sites-enabled/api.local.conf <<EOF
upstream django {
    server unix:///tmp/proxy.sock;
}
upstream ws_server {
    server unix:///tmp/proxy_ws.sock;
}
server{
    listen 8000 default_server;
    listen [::]:8000 default_server;
    server_name api.local;
    client_max_body_size 100M;
    error_log /home/proxy/log/nginx-err.log;

    location /static {

        alias /home/proxy/static;
    }
    location /media {
        alias /home/proxy/media;
    }
    location / {
        uwsgi_pass  django;
        include /home/proxy/proxy/uwsgi_params;
    }

    location /ws {
        proxy_pass http://ws_server;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_redirect off;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Host \$server_name;
    }

}
EOF
  fi

  if ! [ -f /etc/nginx/sites-enabled/panel.local.conf  ]; then
    cat > /etc/nginx/sites-enabled/panel.local.conf  <<EOF
map \$sent_http_content_type \$expires {
    "text/html"                 epoch;
    "text/html; charset=utf-8"  epoch;
    default                     off;
}
server{
    listen 8080 default_server;
    listen [::]:8080 default_server;

    server_name panel.local;
    gzip  on;
    gzip_min_length 1000;
    gzip_types      text/plain application/xml text/css application/javascript;
    client_max_body_size 100M;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-XSS-Protection "1; mode=block";
    add_header X-Content-Type-Options "nosniff";

    location / {
        proxy_pass  http://127.0.0.1:3000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Host \$server_name;
        proxy_set_header X-Forwarded-Proto  \$scheme;
        expires \$expires;
        proxy_redirect              off;
        proxy_read_timeout          1m;
        proxy_connect_timeout       1m;
    }
    location /ws {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_redirect off;
    }
    access_log off;
    error_log /home/proxy/log/nginx-err.log;
}
EOF
  fi
}
function ConfigSupervisorUwsgi {
  if ! [ -f /etc/supervisor/conf.d/uwsgi.conf  ]; then
    cat > /etc/supervisor/conf.d/uwsgi.conf <<EOF
[program:uwsgi]
directory = /home/proxy
command =  /home/proxy/venv/bin/uwsgi --ini proxy/uwsgi.ini
autostart = true
autorestart = true
stderr_logfile = /home/proxy/log/site_uwsgi_err.log
stdout_logfile = /home/proxy/log/site_uwsgi_out.log
stopsignal = QUIT
EOF
  fi
}
function ConfigSupervisorChannels {
  if ! [ -f /etc/supervisor/conf.d/channels.conf  ]; then
    cat > /etc/supervisor/conf.d/channels.conf <<EOF
[program:channels]
directory = /home/proxy
command =  /home/proxy/venv/bin/daphne -u /tmp/proxy_ws.sock --proxy-headers proxy.asgi:application
autostart = true
autorestart = true
stderr_logfile = /home/proxy/log/channels_err.log
stdout_logfile = /home/proxy/log/channels_out.log
stopsignal = QUIT
EOF
  fi
}
function ConfigSupervisorOsfooler {
  if ! [ -f /etc/supervisor/conf.d/osfooler.conf ]; then
 cat > /etc/supervisor/conf.d/osfooler.conf <<EOF
[program:osfooler]
user=root
command=python /home/proxy/devices/osfp/osfooler_ng.py -f "/home/proxy/devices/osfp-conf.json"
autostart=true
autorestart=false
startretries=0
stopasgroup=true
killasgroup=true
stderr_logfile = /home/proxy/log/osfooler-err.log
stdout_logfile = /home/proxy/log/osfooler-out.log
stopsignal=QUIT
EOF

  fi
}
function ConfigSupervisorNodejs {
  if ! [ -f /etc/supervisor/conf.d/nodejs.conf ]; then
 cat > /etc/supervisor/conf.d/nodejs.conf <<EOF
[program:nodejs]
directory = /home/proxy/gui
command = npm run start
autostart = true
autorestart = true
stderr_logfile = /home/proxy/log/nodejs_err.log
stdout_logfile = /home/proxy/log/nodejs_out.log
stopsignal = QUIT
EOF
  fi
}
function ConfigServiceKraken {
  if ! [ -h /etc/systemd/system/monitoring.service  ]; then
    sudo ln -s /home/proxy/conf/monitoring.service  /etc/systemd/system/monitoring.service
    sudo systemctl enable monitoring.service
  fi

  if ! [ -h /etc/systemd/system/operations.service  ]; then
    sudo ln -s /home/proxy/conf/operations.service  /etc/systemd/system/operations.service
    sudo systemctl enable operations.service
  fi

  if ! [ -h /etc/systemd/system/reconnect.service  ]; then
    sudo ln -s /home/proxy/conf/reconnect.service  /etc/systemd/system/reconnect.service
    sudo systemctl enable reconnect.service
  fi

  if ! [ -h /etc/systemd/system/scheduler.service  ]; then
    sudo ln -s /home/proxy/conf/scheduler.service  /etc/systemd/system/scheduler.service
    sudo systemctl enable scheduler.service
  fi

  if [ -f /home/proxy/kraken.sh ]; then
    chmod 755 /home/proxy/kraken.sh
  fi

  if ! [ -h /usr/bin/kraken  ] && [ -f /home/proxy/kraken.sh ]; then
    sudo ln -s /home/proxy/kraken.sh /usr/bin/kraken
  fi
  sudo systemctl daemon-reload
}
function ConfigNetwork {

  case `grep -E "renderer:\s*NetworkManager"  /etc/netplan/00-installer-config.yaml -c` in
          0 )     Debug "add  renderer NetworkManager"
                  sed -i '/version: 2/a\  renderer: NetworkManager'  /etc/netplan/00-installer-config.yaml
                  ;;
          * )     Debug "is renderer NetworkManager"
                  ;;
  esac

  if ! [ -h /etc/udev/rules.d/80-net-setup-link.rules ]; then
    Debug "add ln 80-net-setup-link.rules"
    sudo ln -s /lib/udev/rules.d/80-net-setup-link.rules /etc/udev/rules.d/80-net-setup-link.rules
  fi

  sed -i 's/managed=false/managed=true/' /etc/NetworkManager/NetworkManager.conf
  sed -i 's/managed-devices=.*/managed-devices=*,except:type:wifi,except:type:wwan/' /usr/lib/NetworkManager/conf.d/10-globally-managed-devices.conf

  if [ -f /lib/systemd/system/ModemManager.service ]; then
    case `grep -E "ModemManager\s*--debug"  /lib/systemd/system/ModemManager.service -c` in
            0 )     Debug "add  ModemManager debug"
                    systemctl stop ModemManager
                    sed -i 's/ExecStart=.*/ExecStart=\/usr\/sbin\/ModemManager --debug/' /lib/systemd/system/ModemManager.service
                    systemctl daemon-reload
                    systemctl start ModemManager
                    ;;
            * )     Debug "is ModemManager debug"
                    ;;
    esac
  fi

#  if [ `systemctl status NetworkManager | grep -E "Loaded:\s+loaded\s\([^;]+;\s*enabled;" -c` = 0 ]; then
#      Debug "NetworkManager enable start\n"
#      systemctl enable NetworkManager
#  fi
#
#  if [ `systemctl status ModemManager | grep -E "Loaded:\s+loaded\s\([^;]+;\s*enabled;" -c` = 0 ]; then
#      Debug "ModemManager enable start\n"
#      systemctl enable ModemManager
#  fi


}
function ConfigSystem {

  if [ `grep -E "net.core.somaxconn=.*"  /etc/sysctl.conf -c` = 0 ]; then
    Debug "add  net.core.somaxconn"
    echo 'net.core.somaxconn=65535' >> /etc/sysctl.conf
  else
    Debug "edit net.core.somaxconn"
    sed -i 's/net.core.somaxconn=.*/net.core.somaxconn=65535/' /etc/sysctl.conf
  fi

  if [ `grep -E "net.ipv4.tcp_max_orphans=.*"  /etc/sysctl.conf -c` = 0 ]; then
    Debug "add net.ipv4.tcp_max_orphans"
    echo 'net.ipv4.tcp_max_orphans=65535' >> /etc/sysctl.conf
  else
    Debug "edit net.ipv4.tcp_max_orphans"
    sed -i 's/net.ipv4.tcp_max_orphans=.*/net.ipv4.tcp_max_orphans=65535/' /etc/sysctl.conf
  fi

  if [ `grep -E "net.ipv4.tcp_max_syn_backlog=.*"  /etc/sysctl.conf -c` = 0 ]; then
    Debug "add net.ipv4.tcp_max_syn_backlog"
    echo 'net.ipv4.tcp_max_syn_backlog=65535' >> /etc/sysctl.conf
  else
    Debug "edit net.ipv4.tcp_max_syn_backlog"
    sed -i 's/net.ipv4.tcp_max_syn_backlog=.*/net.ipv4.tcp_max_syn_backlog=65535/' /etc/sysctl.conf
  fi

  if [ `grep -E "fs.file-max=.*"  /etc/sysctl.conf -c` = 0 ]; then
    Debug "add fs.file-max"
    echo 'fs.file-max=65535' >> /etc/sysctl.conf
  else
    Debug "edit fs.file-max"
    sed -i 's/fs.file-max=.*/fs.file-max=65535/' /etc/sysctl.conf
  fi

  if [ `grep -E "session\s+required\s+pam_limits.so" /etc/pam.d/common-session -c` = 0 ]; then
    Debug "add session    required   pam_limits.so > /etc/pam.d/common-session"
    echo 'session    required   pam_limits.so' >> /etc/pam.d/common-session
  fi

  if [ `grep -E "session\s+required\s+pam_limits.so" /etc/pam.d/common-session-noninteractive -c` = 0 ]; then
    Debug "add session    required   pam_limits.so > /etc/pam.d/common-session-noninteractive"
    echo 'session    required   pam_limits.so' >> /etc/pam.d/common-session-noninteractive
  fi

  if [ `grep -E "^\*\s+hard\s+nofile\s+.*"  /etc/security/limits.conf -c` = 0 ]; then
    Debug "add *       hard    nofile  200000"
    echo '*       hard    nofile  200000' >> /etc/security/limits.conf
  else
    Debug "edit *       hard    nofile  200000"
    sed -i 's/^\*\s*hard\s*nofile\s*.*/*       hard    nofile  200000/' /etc/security/limits.conf
  fi

  if [ `grep -E "^\*\s+soft\s+nofile\s+.*"  /etc/security/limits.conf -c` = 0 ]; then
    Debug "add *       soft    nofile  65535"
    echo '*       soft    nofile  65535' >> /etc/security/limits.conf
  else
    Debug "edit *       soft    nofile  65535"
    sed -i 's/^\*\s*soft\s*nofile\s*.*/\*       soft    nofile  65535/' /etc/security/limits.conf
  fi


  if [ `grep -E "^root\s+hard\s+nofile\s+.*"  /etc/security/limits.conf -c` = 0 ]; then
    Debug "add root    hard    nofile  200000"
    echo 'root    hard    nofile  200000' >> /etc/security/limits.conf
  else
    Debug "edit root    hard    nofile  200000"
    sed -i 's/^root\s*hard\s*nofile\s*.*/root    hard    nofile  200000/' /etc/security/limits.conf
  fi

  if [ `grep -E "^root\s+soft\s+nofile\s+.*"  /etc/security/limits.conf -c` = 0 ]; then
    Debug "add root    hard    nofile  65535"
    echo 'root    hard    nofile  65535' >> /etc/security/limits.conf
  else
    Debug "edit root    hard    nofile  65535"
    sed -i 's/^root\s*soft\s*nofile\s*.*/root    soft    nofile  65535/' /etc/security/limits.conf
  fi

  if [ `grep "Europe/Moscow" /etc/timezone -c` = 0 ]; then
    Debug "set timezone Europe/Moscow"
    timedatectl set-timezone 'Europe/Moscow'
  fi

}
function RestartNetworkManager {

    systemctl restart NetworkManager

    if [ `systemctl status NetworkManager | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "NetworkManager error start\n"
    else
      Info "NetworkManager start\n"
    fi

    systemctl restart ModemManager

    if [ `systemctl status ModemManager | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "ModemManager error start\n"
    else
      Info "ModemManager start\n"
    fi
}
function RestartNetwork {
  Debug "restart netplan"
  sudo netplan --debug generate
  sudo netplan apply
  RestartNetworkManager
}
function RestartServiceKraken {

    systemctl restart monitoring.service

    if [ `systemctl status monitoring.service | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "ServiceKraken monitoring error start\n"
    else
      Info "ServiceKraken monitoring start\n"
    fi

    systemctl restart operations.service

    if [ `systemctl status monitoring.service | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "ServiceKraken operations error start\n"
    else
      Info "ServiceKraken operations start\n"
    fi

    systemctl restart reconnect.service

    if [ `systemctl status reconnect.service | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "ServiceKraken reconnect error start\n"
    else
      Info "ServiceKraken reconnect start\n"
    fi

    systemctl restart scheduler.service

    if [ `systemctl status scheduler.service | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "ServiceKraken scheduler error start\n"
    else
      Info "ServiceKraken scheduler start\n"
    fi
}
function RestartSupervisor {

    systemctl restart supervisor

    if [ `systemctl status supervisor | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "Supervisor error start\n"
    else
      Info "Supervisor start\n"
    fi
}
function RestartPostgresql {
    systemctl restart postgresql

    if [ `systemctl status postgresql | grep -E "Active:\s+active" -c` = 0 ]; then
      Danger "Postgresql error start\n"
    else
      Info "Postgresql start\n"
    fi
}
function RestartRabbitmq {
    systemctl restart rabbitmq-server

    if [ `systemctl status rabbitmq-server | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "Rabbitmq-server error start\n"
    else
      Info "Rabbitmq-server start\n"
    fi
}
function RestartRedis {
    systemctl restart redis-server

    if [ `systemctl status redis-server | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "Redis-server error start\n"
    else
      Info "Redis-server start\n"
    fi
}
function RestartNginx {
    service nginx reload
    systemctl restart nginx
    if [ `systemctl status nginx | grep -E "Active:\s+active\s+\(running\)" -c` = 0 ]; then
      Danger "Nginx error start\n"
    else
      Info "Nginx start\n"
    fi
}
function FinishInstallation {
  export IP=`ip -o -4 address show scope global | tr '/' ' ' | awk '$3~/^inet/ && $2~/^(eth|veth|venet|ens|eno|enp)[0-9]+$|^enp[0-9]+s[0-9a-z]+$/ {print $4}'|head -1`
  echo ""
  Message "\nПанель управления http://$IP:8080/\n"
  Message "Доступ RestAPI http://$IP:8000/\n"
}
function InstallKrakenProxy {
  ShowLogo
  Message "Installing Kraken Proxy package.\n"
  CheckUnzipPackage
  InstallPanelRepository
  UpdateSoftwareList
  CheckNetworkManagerPackage
  CheckRabbitmqServerPackage
  CheckRedisServerPackage
  CheckPostgresqlServerPackage
  CheckNginxServerPackage
  CheckLibPackage
  CheckPythonNfqueueServerPackage
  CheckOSFPLibPackage
  Check3PoxyPackage
  ConfigRabbitmq
  ConfigPostgresql
  ConfigNetwork
  ConfigSystem
  CheckKrakenPackage
  ConfigNginx
  ConfigSupervisorUwsgi
  ConfigSupervisorChannels
  ConfigSupervisorOsfooler
  ConfigSupervisorNodejs
  ConfigServiceKraken
  RestartNetwork
  RestartPostgresql
  RestartRedis
  RestartRabbitmq
  RestartSupervisor
  RestartNginx
  RestartServiceKraken
  FinishInstallation
}
function CheckServerConfiguration {
    export INSTALLED_SOFTWARE=''
    Message "Start pre-installation checks\n"
    Message "OS:\t" && Info "${PRETTY_NAME}\n\n"
    CheckSystemd
    CheckPreinstalledPackages
    if [ "${INSTALLED_SOFTWARE[*]}" != '' ] && [ "${force}" != '1' ]; then
        Message "The following software have been found installed: ${INSTALLED_SOFTWARE[*]}.\n"
        Warning "\nThe Control Panel can only be installed on a fresh OS installation.\nYou can use the -f flag to ignore the installed software.\n"
        exit 1
    fi

}
function CheckPreinstalledPackages {
  local PACKAGES="network-manager libdbus-glib-1-dev libpq-dev
  libnetfilter-queue1 redis-server rabbitmq-server supervisor python3-dev
  build-essential python-pip nginx"

  for package in ${PACKAGES}; do

      case `dpkg --get-selections | grep -E "${package}\s+install" -c` in
          0 )
            Debug "Package '${package}' not installed."
            ;;
          * )
            Message "${INSTALLED_SOFTWARE}"
            INSTALLED_SOFTWARE+=("${package}")
            ;;
      esac
  done
}
function CheckSystemd {
    Debug "Checking init daemon.\n"
    case ${VERSION_ID} in
        7 )     case `dpkg --get-selections |grep -E "systemd-sysv\s+install" -c` in
                    1 )     Error "\nDebian Wheezy with systemd doesn't supported."
                            ;;
                    0 )     Debug "Package 'systemd-sysv' not installed.\n"
                            ;;
                esac
                ;;
        * )     case `dpkg --get-selections |grep -E "systemd-sysv\s+install" -c` in
                    0 )     Error "OS ${OS} without systemd doesn't supported.\nPlease install systemd-sysv."
                            ;;
                    1 )     Debug "Package 'systemd-sysv' is installed."
                            ;;
                esac
                ;;
    esac
}
function GetVersion {
  if IsKrakenPackage; then
    ActiveVenv
    python manage.py proxy_version >&3
  fi
}
function ResetKraken {
  if IsKrakenPackage; then
    ActiveVenv

    echo -n "Delete all data? (Y/N): " >&3
    read confirm
    if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] ; then
      python manage.py proxy_reset >&3
      python manage.py createsuperuser >&3
      python manage.py create_token_superuser
    fi
  fi
}

function ResetAdmin {
  if IsKrakenPackage; then
    ActiveVenv

    echo -n "Delete admin? (Y/N): " >&3
    read confirm
    if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] ; then
      python manage.py admin_reset >&3
      python manage.py createsuperuser >&3
      python manage.py create_token_superuser
    fi
  fi
}
function ResetLog {
  if IsKrakenPackage; then
    ActiveVenv

    echo -n "Clear logs and statistics (Y/N): " >&3
    read confirm
    if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] ; then
      python manage.py clear_debug >&3
    fi
  fi
}
function UpdateKraken {

  if ! IsKrakenPackage; then
    Error "The update is not possible because the application itself is not installed"
  fi

  ShowLogo
  Message "Update Kraken Proxy package.\n"

  if ! [ -f /home/kraken_proxy_update_dist.zip ];  then

    local error_text=""

    for domain in ${DOMAINS}; do

        if ! wget --quiet -O /home/kraken_proxy_update_dist.zip "https://${domain}/api/license/dist/update"; then
            rm /home/kraken_proxy_update_dist.zip
            error_text="not wget download (https://${domain}/api/license/dist/update) update dist kraken proxy, add your ip in your account"
        else
            error_text=""
            break
        fi
    done

    if [ -n "${error_text}" ]; then
      Error "${error_text}"
    fi

    Message "Download update dist kraken proxy\n"
  fi

  if [ -d /home/proxy_update ]; then
    Debug "Delete directory 'proxy_update'"
    rm -r /home/proxy_update
  else
    Debug "Unzip package kraken_proxy_update_dist.zip"
    unzip /home/kraken_proxy_update_dist.zip -d /home
  fi

  cp -uR /home/proxy_update/* /home/proxy/

  if [ -d /home/proxy/gui/.nuxt ]; then
    rm -r /home/proxy/gui/.nuxt
  fi

  cp -uR /home/proxy_update/gui/.nuxt /home/proxy/gui/

  Check3PoxyPackage
  ConfigNetwork
  ConfigServiceKraken
  InstallLibKraken
  MigrateDataBase

  Info "Update Kraken Proxy package\n"

  if [ -d /home/proxy_update ]; then
    Debug "After update delete directory 'proxy_update'"
    rm -r /home/proxy_update
  fi

  if [ -f /home/kraken_proxy_update_dist.zip ]; then
    Debug "After update delete directory 'kraken_proxy_update_dist.zip'"
    rm /home/kraken_proxy_update_dist.zip
  fi
}
function Run {
    SetLogFile
    CheckIsUserRoot
    CheckArch
    CheckVersionOS
    ParseParameters $@
    if [ "${smtp}" = '1' ]; then
        SmtpSettings
        RestartSupervisor
        RestartServiceKraken
    elif [ "${restart}" = '1' ]; then
        RestartRedis
        RestartRabbitmq
        RestartNginx
        RestartPostgresql
        RestartNetworkManager
        RestartSupervisor
        RestartServiceKraken
    elif [ "${version}" = '1' ]; then
        GetVersion
    elif [ "${reset}" = '1' ]; then
        ResetKraken
        RestartSupervisor
        RestartServiceKraken
    elif [ "${clear}" = '1' ]; then
        ResetLog
    elif [ "${radmin}" = '1' ]; then
        ResetAdmin
    elif [ "${update}" = '1' ]; then
        UpdateKraken
        RestartRedis
        RestartRabbitmq
        RestartNginx
        RestartPostgresql
        RestartNetworkManager
        RestartSupervisor
        RestartServiceKraken
        FinishInstallation
    else
        CheckServerConfiguration
        InstallKrakenProxy
    fi

}
Run $@