from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token

class Command(BaseCommand):
    help = ''

    def handle(self, *args, **kwargs):
        for user in User.objects.filter(is_superuser=True).all():
            if not Token.objects.filter(user=user).count():
                Token.objects.create(user=user)
                self.stdout.write("Токен прользователя %s создан" % user.username)
            else:
                self.stdout.write("Пользователь %s не найден" % user.username)